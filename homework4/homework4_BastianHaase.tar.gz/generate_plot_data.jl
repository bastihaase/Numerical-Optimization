include("mesh.jl")
xgrid=create_grid(25,0.1,5)
ygrid=create_grid(25,0.1,5)
zgrid=zeros(26,26)
for i = 1:26
	for j = 1:26
		zgrid[i,j]=log(f([xgrid[i],ygrid[j]])[1])
	end
end

